# Project1
This is our CSC4410 Project at LSU. Gaelan Harrington and Sam Fadrigalan pair programmed this project. :)
(still in progress)